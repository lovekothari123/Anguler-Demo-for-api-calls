import { Component } from "@angular/core";

import 'node_modules/grapesjs'
@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.scss"]
})
export class AppComponent {
  title = "dashboard";
}
